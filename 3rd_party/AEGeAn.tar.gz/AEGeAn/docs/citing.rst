Citing AEGeAn
=============
Use the following if you want to cite the AEGeAn Toolkit as a whole.

* **Daniel S. Standage** (2010-2015). AEGeAn: an integrated toolkit for analysis
  and evaluation of annotated genomes, http://standage.github.io/AEGeAn.

ParsEval was intially developed as an independent tool and published on its own.
It has now been integrated with the AEGeAn Toolkit, but if you use ParsEval you
should still cite the original paper.

* **Daniel S. Standage** and Volker P. Brendel (2012) ParsEval: parallel
  comparison and analysis of gene structure annotations. *BMC Bioinformatics*,
  13:187, `doi:10.1186/1471-2105-13-187
  <http://dx.doi.org/10.1186/1471-2105-13-187>`_.
