#ifndef AEGEAN_VERSION_H
#define AEGEAN_VERSION_H
#define AGN_SEMANTIC_VERSION  "v0.14.0"
#define AGN_VERSION_STABILITY "stable"
#define AGN_VERSION_HASH      "64f3e0f92453781f99ee83b3566ebb24d19ed2df"
#define AGN_VERSION_HASH_SLUG "64f3e0f924"
#define AGN_VERSION_LINK      "https://github.com/standage/AEGeAn/tree/64f3e0f92453781f99ee83b3566ebb24d19ed2df"
#define AGN_COPY_YEAR         "2015"
#endif
