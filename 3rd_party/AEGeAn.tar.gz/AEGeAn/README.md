# AEGeAn Toolkit

AEGeAn: <b>a</b>nalysis and <b>e</b>valuation of <b>ge</b>nome <b>an</b>notations

Copyright (c) 2010-2015, Daniel S. Standage and CONTRIBUTORS.
See LICENSE and for details.
Project homepage: http://standage.github.io/AEGeAn.

[![AEGeAn build status](https://api.travis-ci.org/standage/AEGeAn.svg?branch=master)](https://travis-ci.org/standage/AEGeAn)
[![Coverity Scan build status](https://scan.coverity.com/projects/1021/badge.svg)](https://scan.coverity.com/projects/1021)
[![ReadTheDocs build status](https://readthedocs.org/projects/aegean/badge/?version=latest)](https://readthedocs.org/projects/aegean/badge/?version=latest)

