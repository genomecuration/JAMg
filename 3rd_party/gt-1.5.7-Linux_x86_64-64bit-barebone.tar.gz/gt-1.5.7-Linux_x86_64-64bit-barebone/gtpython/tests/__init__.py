#!/usr/bin/python
# -*- coding: utf-8 -*-

from test_alphabet import *
from test_commentnode import *
from test_customvisitor import *
from test_encseq import *
from test_featurenode import *
from test_metanode import *
from test_sequencenode import *
from test_iterators import *
from test_stream import *
from test_range import *

import unittest
unittest.main()
